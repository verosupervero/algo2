#ifndef PROCESAR_SUBCADENA_H
#define PROCESAR_SUBCADENA_H
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

bool mostrar_subcadena_en_archivo(char *subcadena, size_t N, FILE * archivo);

#endif
